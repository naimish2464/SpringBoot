package com.example.crud.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.Model.Student;
import com.example.crud.Service.StudentService;

@Controller
@RequestMapping("/student")
public class studentController {

	@Autowired
	StudentService service;
	
	@GetMapping("/")
	public String getAllStud(Model model) {
		model.addAttribute("students", service.getAll());
		return "view-emp";
	}
	
	@GetMapping("/create")
	public String createstudent(Model model) {
		model.addAttribute("students", new Student());
		
		return "insert-emp";
	}
	
	@PostMapping
	public String insert(@ModelAttribute Student student) {
		service.save(student);
		return "redirect:/student/view";
		
		
	}
	
	@GetMapping("/edit/{id}")
	public String editEmployee(@PathVariable("id") Long id, Model model) {
		Student stu = service.getbyId(id);
		model.addAttribute("student", stu);
		return "edit-emp";
		
	}
	
	@PostMapping("/{id}")
	public String updateEmployee(@PathVariable ("id") Long id, @ModelAttribute Student stud) {
		
		stud.setId(id);
		service.save(stud);
		return "redirect:/student/view";
		
	}
	
	@GetMapping("/delete/{id}")
	public void delete(@PathVariable("id") Long id) {
		service.deletebyId(id);
	}
	
}
