package com.example.crud.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Model.Student;
import com.example.repository.Studentrepo;

@Service
public class StudentService {
	

	Studentrepo repo;
	
	
	public List<Student> getAll() {
		return repo.findAll();
	}
	
	public Student save(Student student) {
		return repo.save(student);
	}
	
	public Student getbyId(Long id) {
		return repo.findById(id).orElse(null);
		
	}
	
	public void deletebyId(Long id) {
		 repo.deleteById(id);
	}
}
